<?php

class Mom_Mailchimp_Mobile {
    public function __construct(Mom_Mailchimp $master) {
        $this->master = $master;
    }

}



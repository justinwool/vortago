<?php

class Mom_Mailchimp_Neapolitan {
    public function __construct(Mom_Mailchimp $master) {
        $this->master = $master;
    }

}


